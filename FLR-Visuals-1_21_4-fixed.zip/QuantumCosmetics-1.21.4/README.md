# FLR Visuals — Minecraft 1.21.4 (Fabric)

Dark cosmetic client mod. Client-side only.

## Features
- **Right Shift** — open the FLR Visuals menu (press again to close)
- **Free Look** — hold **Left Alt**: camera orbits freely, your character keeps facing forward
- **Hand Animations** — smooth slash arc on top of the vanilla swing
- **Cosmetics** — rotating halo above your head (visible in third person / Free Look)
- **Particles** — sparkle trail while you move
- **Performance Mode** — minimal particles, clouds off, entity shadows off (restored when turned off)

Keys can be rebound in Controls → FLR Visuals.

## Build
Requires JDK 21 and Gradle 8.11+.

    gradle wrapper --gradle-version 8.12   # once, to create ./gradlew
    ./gradlew build

The jar is in `build/libs/flr-visuals-1.0.0.jar`. Put it in `mods/` together with
Fabric API for 1.21.4 (0.119.2+1.21.4 or newer) and Fabric Loader 0.16.10+.

No combat automation (KillAura etc.) is included.
