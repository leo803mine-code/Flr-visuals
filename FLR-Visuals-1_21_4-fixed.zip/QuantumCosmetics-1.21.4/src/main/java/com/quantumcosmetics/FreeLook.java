package com.quantumcosmetics;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;

/** Camera detaches from the player's head while the Free Look key is held. */
public final class FreeLook {
    public static boolean active = false;
    public static float yaw;
    public static float pitch;
    private static Perspective previous = null;

    private FreeLook() {}

    public static void update(MinecraftClient client, boolean keyHeld) {
        boolean want = keyHeld && Config.freeLookEnabled && client.player != null
                && client.currentScreen == null;

        if (want && !active) {
            active = true;
            yaw = client.player.getYaw();
            pitch = client.player.getPitch();
            previous = client.options.getPerspective();
            if (previous == Perspective.FIRST_PERSON) {
                client.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            }
        } else if (!want && active) {
            active = false;
            if (previous != null && client.options.getPerspective() != previous) {
                client.options.setPerspective(previous);
            }
            previous = null;
        }
    }

    public static void rotate(double dx, double dy) {
        yaw += (float) dx * 0.15F;
        pitch = MathHelper.clamp(pitch + (float) dy * 0.15F, -90.0F, 90.0F);
    }
}
