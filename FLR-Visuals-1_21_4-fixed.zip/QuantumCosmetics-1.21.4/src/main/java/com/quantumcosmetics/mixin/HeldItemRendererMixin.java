package com.quantumcosmetics.mixin;

import com.quantumcosmetics.Config;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    // Smooth "slash" arc on top of the vanilla swing.
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void flr$handAnimation(AbstractClientPlayerEntity player, float tickDelta, float pitch,
                                   Hand hand, float swingProgress, ItemStack item, float equipProgress,
                                   MatrixStack matrices, VertexConsumerProvider vertexConsumers,
                                   int light, CallbackInfo ci) {
        if (!Config.handAnimations || swingProgress <= 0.0F) return;
        float s = MathHelper.sin(swingProgress * (float) Math.PI);
        matrices.translate(0.0F, -0.08F * s, -0.10F * s);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-18.0F * s));
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(12.0F * s));
    }
}
