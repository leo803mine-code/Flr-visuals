package com.quantumcosmetics;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class CosmeticsScreen extends Screen {
    private static final Identifier LOGO =
            Identifier.of("flrvisuals", "textures/gui/logo.png");

    private static final int PANEL_W = 360;
    private static final int PANEL_H = 280;

    public CosmeticsScreen() {
        super(Text.literal("FLR Visuals"));
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 112;
        int y = (this.height - PANEL_H) / 2 + 100;

        addDrawableChild(toggle("Free Look", () -> Config.freeLookEnabled,
                v -> Config.freeLookEnabled = v, x, y));
        addDrawableChild(toggle("Hand Animations", () -> Config.handAnimations,
                v -> Config.handAnimations = v, x, y + 24));
        addDrawableChild(toggle("Cosmetics (halo)", () -> Config.cosmetics,
                v -> Config.cosmetics = v, x, y + 48));
        addDrawableChild(toggle("Particles (trail)", () -> Config.particles,
                v -> Config.particles = v, x, y + 72));
        addDrawableChild(toggle("Performance Mode", () -> Config.performanceMode,
                v -> Config.performanceMode = v, x, y + 96));

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(x, y + 126, 224, 20).build());
    }

    private ButtonWidget toggle(String name, BooleanSupplier state,
                                Consumer<Boolean> setter, int x, int y) {
        return ButtonWidget.builder(label(name, state.getAsBoolean()), b -> {
            boolean now = !state.getAsBoolean();
            setter.accept(now);
            b.setMessage(label(name, now));
        }).dimensions(x, y, 224, 20).build();
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (QuantumCosmeticsClient.menuKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta); // background + widgets

        int x = (width - PANEL_W) / 2, y = (height - PANEL_H) / 2;

        context.drawTextWithShadow(textRenderer, Text.literal("FLR VISUALS"),
                x + 94, y + 25, 0xFFFFFFFF);
        context.drawTextWithShadow(textRenderer, Text.literal("1.21.4  \u2022  COSMETIC CLIENT"),
                x + 94, y + 42, 0xFF8D8499);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        super.renderBackground(context, mouseX, mouseY, delta);

        int x = (width - PANEL_W) / 2, y = (height - PANEL_H) / 2;

        // Deep-dark panel with a purple accent line.
        context.fill(x, y, x + PANEL_W, y + PANEL_H, 0xF20A0A0F);
        context.fill(x + 1, y + 1, x + PANEL_W - 1, y + 2, 0xFF7A5CFF);
        context.drawBorder(x, y, PANEL_W, PANEL_H, 0xFF292332);

        context.drawTexture(RenderLayer::getGuiTextured, LOGO,
                x + 18, y + 18, 0, 0, 64, 64, 64, 64);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
