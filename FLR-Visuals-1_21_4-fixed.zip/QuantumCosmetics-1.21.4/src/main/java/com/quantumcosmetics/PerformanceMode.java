package com.quantumcosmetics;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.ParticlesMode;

/** Lowers a few expensive video options and restores them when turned off. */
public final class PerformanceMode {
    private static boolean applied = false;
    private static ParticlesMode oldParticles;
    private static CloudRenderMode oldClouds;
    private static boolean oldShadows;

    private PerformanceMode() {}

    public static void sync(MinecraftClient client) {
        if (client.options == null) return;
        if (Config.performanceMode && !applied) {
            oldParticles = client.options.getParticles().getValue();
            oldClouds = client.options.getCloudRenderMode().getValue();
            oldShadows = client.options.getEntityShadows().getValue();
            client.options.getParticles().setValue(ParticlesMode.MINIMAL);
            client.options.getCloudRenderMode().setValue(CloudRenderMode.OFF);
            client.options.getEntityShadows().setValue(false);
            applied = true;
        } else if (!Config.performanceMode && applied) {
            client.options.getParticles().setValue(oldParticles);
            client.options.getCloudRenderMode().setValue(oldClouds);
            client.options.getEntityShadows().setValue(oldShadows);
            applied = false;
        }
    }
}
