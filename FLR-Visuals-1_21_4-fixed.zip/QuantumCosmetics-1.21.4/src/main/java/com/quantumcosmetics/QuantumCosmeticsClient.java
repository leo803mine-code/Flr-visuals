package com.quantumcosmetics;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.ParticleTypes;
import org.lwjgl.glfw.GLFW;

public class QuantumCosmeticsClient implements ClientModInitializer {
    public static KeyBinding menuKey;
    public static KeyBinding freeLookKey;

    private static int ticks = 0;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.flrvisuals.menu", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.flrvisuals"));

        freeLookKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.flrvisuals.freelook", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_ALT, "category.flrvisuals"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new CosmeticsScreen());
                }
            }

            FreeLook.update(client, freeLookKey.isPressed());
            PerformanceMode.sync(client);
            spawnCosmetics(client);
        });
    }

    private static void spawnCosmetics(MinecraftClient client) {
        ClientPlayerEntity p = client.player;
        if (p == null || client.world == null || client.isPaused()) return;
        ticks++;

        // Halo ring above the head (visible in third person / Free Look).
        if (Config.cosmetics && ticks % 2 == 0) {
            int points = Config.performanceMode ? 3 : 6;
            double base = ticks * 0.12;
            for (int i = 0; i < points; i++) {
                double a = base + i * (Math.PI * 2 / points);
                client.world.addParticle(ParticleTypes.END_ROD,
                        p.getX() + Math.cos(a) * 0.35,
                        p.getY() + p.getHeight() + 0.25,
                        p.getZ() + Math.sin(a) * 0.35,
                        0, 0, 0);
            }
        }

        // Sparkle trail while moving.
        if (Config.particles && !Config.performanceMode && ticks % 3 == 0
                && p.getVelocity().horizontalLengthSquared() > 0.001) {
            client.world.addParticle(ParticleTypes.ELECTRIC_SPARK,
                    p.getX() + (p.getRandom().nextDouble() - 0.5) * 0.5,
                    p.getY() + 0.1,
                    p.getZ() + (p.getRandom().nextDouble() - 0.5) * 0.5,
                    0, 0.02, 0);
        }
    }
}
