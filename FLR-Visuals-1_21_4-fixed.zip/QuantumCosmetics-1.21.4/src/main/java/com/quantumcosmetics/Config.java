package com.quantumcosmetics;

public final class Config {
    public static boolean freeLookEnabled = true;
    public static boolean handAnimations = true;
    public static boolean cosmetics = true;
    public static boolean particles = true;
    public static boolean performanceMode = false;

    private Config() {}
}
